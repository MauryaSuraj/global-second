@extends('layouts.admin')
@section('content-admin')
    <div class="container">
        <div class="row">
            <h1>
                user, those has special request
            </h1>
        </div>
    </div>
@endsection
