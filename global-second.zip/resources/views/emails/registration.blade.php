<h1>
    Registration Confirm
User name :     {{ $username }}
    Email : {{ $email }}
</h1>
