<?php $__env->startSection('content'); ?>

    <div class="bg-listing py-5">
        <div class="container">
            <div class="row my-5">
                <div class="col-md-12">
                    <h2 class="h1-responsive font-weight-bold text-center text-white my-2">Our Listings</h2>
                    <p class="grey-text text-center w-responsive text-white mx-auto mb-3">Lorem ipsum dolor sit amet, consectetur
                        adipisicing elit. Fugit, error amet numquam iure provident voluptate esse quasi, veritatis totam voluptas
                        nostrum quisquam eum porro a pariatur veniam.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <section class="text-center">
                    <div class="row">
                        <div class="col-md-3">
                            <h2 class="text-left">Category</h2>
                            <hr>
                            <ul class="list-group">
                                <?php if($categories): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item text-left"><a href="<?php echo e(route('search.show',$category->id)); ?>"><span class="mr-2"> <img style="width: 40px" src="<?php echo e(url('images/').'/category/'.$category->image); ?>" alt=""> </span> <span class="font-weight-lighter"><?php echo e($category->name); ?></span></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                            <h2 class="text-left">Tags</h2>
                            <hr>
                            <div class="d-flex">
                                <?php if($tags): ?>
                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="bg-primary rounded-pill text-white p-1 mr-1 "> <i class="fas fa-tag p-1"></i> <?php echo e($tag->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <?php if($query): ?>

                                <div class="my-3">
                                    <h2 class="h2">You have searched for :  <span class="text-success p-1 text-white"><?php echo e($query); ?></span> </h2>
                                </div>
                                <?php endif; ?>
                            <?php if($listings != null): ?>
                                <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 my-2">
                                        <div class="card card-cascade narrower card-ecommerce">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <img src="<?php echo e(url('images/').'/listing/'.$listing->image); ?>" class="h-100 w-100">
                                                </div>
                                                <div class="col-md-6 py-2">
                                                    <div class="card-body text-left card-body-cascade">
                                                        <h4 class="card-title"><strong><a href=""><?php echo e($listing->name); ?></a></strong></h4>
                                                        <p class="card-text text-justify">
                                                            <?php echo e(substr($listing->description,0,strpos($listing->description, ' ', 250) )); ?>

                                                        </p>
                                                        <p class="card-text text-justify">

                                                        </p>
                                                        <p class="d-flex justify-content-between">
                                                            <span> <strong>Price : </strong>  Rs.<?php echo e($listing->price); ?></span>
                                                            <a href="/listing/<?php echo e($listing->id); ?>" class="btn btn-outline-danger ">View</a>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <h1 class="text-center">No Listing Found based On your Query</h1>
                                <?php echo e($listings->links()); ?>

                            <?php endif; ?>
                        </div>

                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARA_PROJECT_SURAJ\global\global-second\resources\views/search/search.blade.php ENDPATH**/ ?>