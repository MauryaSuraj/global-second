<?php $__env->startSection('content'); ?>
    <div class="bg-about-page">
        <div class="container">
            <div class="row">
                <div class="col-md text-center py-5">
                    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="d-block w-100" src="<?php echo e(url('images/').'/listing/'.$bu_list->image); ?>" >
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="<?php echo e(url('images/').'/listing/'.$bu_list->image); ?>" >
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" src="<?php echo e(url('images/').'/listing/'.$bu_list->image); ?>" >
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="single-page-title-bar single-post mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xs-12 col-md-10 col-sm-12">
                    <div class="short-detail">
                        <div class="list-category"><ul> <li>  <a href="javascript:void(0)">  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($category->name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </a> </li> </ul></div>
                        <div class="list-heading"> <h2><?php echo e($bu_list->name); ?> </h2> </div>
                        <div class="list-meta">
                            <ul>
                                <li><span class="list-posted-date"><?php echo e($bu_list->created_at); ?></span></li>
                                <li> <span class="ratings"> <i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star color" aria-hidden="true"></i><i class="fa fa-star-half-o color" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i> <i class="rating-counter"> (4 ratings)</i> </span> </li>
                                <li class="list-meta-with-icons"><a href="javascript:void(0)">Views : <?php echo e($bu_list->views); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="main-contentiner map-half-content" style="padding:0;">
        <div class="container-fluid">
                       <section class="single-post single-detail-page">
                <div class="container">
                    <div class="row">
                        <div class="heading-master">
                        </div>
                        <div class="col-lg-8 col-xs-12 col-md-8 col-sm-12">
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="list-detail">
                                <div class="panel-group" id="accordion_listing_detial" role="tablist" aria-multiselectable="true">

                                    <div class="panel panel-default" id="d-desc">
                                        <div class="panel-heading" role="tab" id="ed-slot-1"> <h4 class="panel-title px-2 py-3 ml-3 h3">  Description </h4></div>
                                        <div class="panel-collapse">
                                            <div class="panel-body"><p><?php echo e($bu_list->description); ?></p></div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default" id="dlisting-video">
                                        <div class="panel-heading" role="tab" id="ed-slot-1"> <h4 class="panel-title px-2 py-3 ml-3 h3">  Video </h4></div>
                                        <div id="d-video-coll" class="panel-collapse" role="tabpanel" aria-labelledby="d_list_video">
                                        <div class="panel-body">
                                                <iframe width="100%" height="370"
                                                        src="<?php echo e($bu_list->video); ?>" frameborder="0"
                                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                                        allowfullscreen></iframe>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default" id="d-comments">
                                        <div class="panel-heading" role="tab" id="ed-slot-1"> <h4 class="panel-title px-2 py-3 ml-3 h3">  Reviews </h4></div>
                                        <div class="panel-collapse">
                                            <div class="panel-body">

                                             <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                                                    <form method="POST" action="<?php echo e(route('userreview.store')); ?>">
                                                        <?php echo csrf_field(); ?>

                                                        <div class="form-group row">
                                                            <div class="col-md-12">
                                                                <input type="hidden" hidden name="listing_id" value="<?php echo e($bu_list->id); ?>">
                                                                <textarea id="description" type="text" placeholder="Give Your review here ....." class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="description" value="<?php echo e(old('description')); ?>" required autocomplete="description"></textarea>
                                                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row mb-0">
                                                            <div class="float-right col-md-12">
                                                                <button type="submit" class="btn btn-primary">
                                                                    <?php echo e(__('Review Us')); ?>

                                                                </button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    <div class="col-md-12">
                                                        <?php if($msgs): ?>
                                                            <div class="alert alert-success mt-3">
                                                                <?php echo e($msgs); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                 <?php else: ?>
                                                    <div class="alert custom-alert custom-alert--warning" role="alert">
                                                        <div class="custom-alert__top-side">
                                                            <span
                                                                class="alert-icon custom-alert__icon  ti-info-alt "></span>
                                                            <div class="custom-alert__body">
                                                                <h6 class="custom-alert__heading">
                                                                    Login To Write A Review. </h6>
                                                                <div class="custom-alert__content">
                                                                    Sorry, you don't have permissions to post a review.
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-12">
                                                                        <a href="/login" class="btn btn-outline-primary">Login</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                 <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="reviews p-4">
                                <div class="review-filters">
                                    <div class="row">
                                        <div class="col-md-12 col-xs-12 col-sm-12">
                                            <div class="review-title">
                                                <h3 class="py-2">User Reviews</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="review-box bg-light p-2">
                                        <div class="review-author-left">
                                            <div class="review-author-img">
                                                <a href="#"><img
                                                        src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/1024px-No_image_available.svg.png"
                                                        class="img-responsive" alt="">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="review-author-right">
                                            <div class="review-author-detail">
                                                <h4><?php echo e($review->description); ?></h4>
                                                <div class="review-detail-meta">
                                                    <span class="ratings">
                                                        <i class="fa fa-star text-danger"></i>
                                                        <i class="fa fa-star text-danger"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    </span>
                                                    By
                                                    <strong>User Name here</strong></a> on <strong><?php echo e($review->created_at); ?></strong>
                                                </div>
                                                <p><?php echo e($review->description); ?></p>
                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 dwt_listing_listing-detialz">

                            <div class="pricing-widget widget">
                                <img src="http://globalagra-vaishchamber.com/wp-content/themes/dwt-listing/assets/images/icons/price.png"
                                     alt="Pricing">
                                <span class="tool-tip h5" title="Expensive">Pricing</span>
                                <span class="price-status  pull-right"> <strong>Rs. <?php echo e($bu_list->price); ?></strong> </span>
                            </div>

                            <div class="widget">
                                <div class="h5">
                                     <span class="mr-3 h5"><img src="https://image.flaticon.com/icons/svg/138/138237.svg" style="width: 40px" alt=""></span> Tags
                                </div>
                                <div class="listing-tagcloud">
                                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="#"># <?php echo e($tag->name); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="widget">
                                <div class="row">
                                    <h4 class="my-2 ml-2"> Listing Address </h4>
                                    <hr>
                                    <div class="col-md-12">
                                        <ul class="list-group my-3">
                                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p> <?php echo e($location->address); ?> , <?php echo e($location->city); ?> , <?php echo e($location->area); ?> , <?php echo e($location->pincode); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="widget">
                                <div class="col-md-12">
                                    <div class="business-hours">
                                        <h2 class="h3">Opening Hours</h2>
                                        <ul class="list-unstyled opening-hours">
                                            <li>Sunday <span class="pull-right">Closed</span></li>
                                            <li>Monday <span class="pull-right"><?php echo e($bu_list->opening_time); ?>- <?php echo e($bu_list->closing_time); ?></span></li>
                                            <li>Tuesday <span class="pull-right"><?php echo e($bu_list->opening_time); ?>- <?php echo e($bu_list->closing_time); ?></span></li>
                                            <li>Wednesday <span class="pull-right"><?php echo e($bu_list->opening_time); ?>- <?php echo e($bu_list->closing_time); ?></span></li>
                                            <li>Thursday <span class="pull-right"><?php echo e($bu_list->opening_time); ?>- <?php echo e($bu_list->closing_time); ?></span></li>
                                            <li>Friday <span class="pull-right"><?php echo e($bu_list->opening_time); ?>- <?php echo e($bu_list->closing_time); ?></span></li>
                                            <li>Saturday <span class="pull-right"><?php echo e($bu_list->opening_time); ?>- <?php echo e($bu_list->closing_time); ?></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item w-50  ">
                                    <a class="nav-link active font-weight-bold" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home"  aria-selected="true">Business Listed By</a>
                                </li>
                                <li class="nav-item w-50  ">
                                    <a class="nav-link font-weight-bold" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Contact us</a>
                                </li>

                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <p>Name :   <?php echo e($profile->name); ?></p>
                                        <p>Email : <?php echo e($profile->email); ?>  </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                    <form method="POST" action="<?php echo e(route('listing.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group row">

                                            <div class="col-md-12">
                                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" placeholder="Name" autofocus>

                                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <input type="hidden" hidden name="listing_id" value="<?php echo e($bu_list->id); ?>">
                                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email">
                                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <input id="phone" type="text"  placeholder="Phone" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone" value="<?php echo e(old('phone')); ?>" required autocomplete="phone">
                                                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <textarea id="message" type="text" placeholder="Message here" class="form-control <?php if ($errors->has('message')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('message'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="message" value="<?php echo e(old('message')); ?>" required autocomplete="message"></textarea>
                                                <?php if ($errors->has('message')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('message'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-0">
                                            <div class="col-md-6 offset-md-4">
                                                <button type="submit" class="btn btn-primary">
                                                    <?php echo e(__('Submit')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                    <p>
                                    <?php if(session()->has('success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session()->get('success')); ?>

                                        </div>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LARA_PROJECT_SURAJ\global\global-second\resources\views/listing/show.blade.php ENDPATH**/ ?>