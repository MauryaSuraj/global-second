<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeaturedMember extends Model
{
    protected $guarded =[];
}
