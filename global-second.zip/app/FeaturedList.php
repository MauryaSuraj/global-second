<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeaturedList extends Model
{
    //
    protected $guarded = [];
}
